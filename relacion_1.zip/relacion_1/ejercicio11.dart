void main() {
  int n=5,factorial=1;
  for (int i = n; i >= 1; i--) {
    factorial=factorial*n;
  }
  print('La suma de los números es:' + '$factorial');
}