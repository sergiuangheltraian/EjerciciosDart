void main() {
  List<String> dias = ['Lunes', 'Martes','Miercoles','Jueves','Viernes'];
  dias.add('Sabado');
  dias.add('Domingo');

  dias.forEach((dias) {
  print('$dias');
});
}