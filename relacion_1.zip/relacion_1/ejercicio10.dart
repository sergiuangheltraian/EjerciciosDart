void main() {
  int n=5,suma=0;
  for (int i = 1; i <= n; i++) {
    suma=suma+n;
  }
  print('La suma de los números es:' + '$suma');
}