void main() {
  int dividendo=19,divisor=5,cociente,resto;
  //int cociente=mayor ~/ menor;
  cociente = dividendo~/divisor;
  resto = dividendo-divisor*cociente;

  print('El cociente es: $cociente \nY el resto es: $resto');
}