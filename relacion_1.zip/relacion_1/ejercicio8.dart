import 'dart:io';

void main() {
  stdout.write("Escriba el número del que quiere la tabla de multiplicar:");
  int a = stdin.readByteSync();
  int numero;

  for (int i=0 ; i<10 ; i++) {
    numero=i*a;
    print('$numero');
  }
}