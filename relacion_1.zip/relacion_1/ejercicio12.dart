void main() {
  int num1=8,num2=7,comun=0;
  //int cociente=mayor ~/ menor;
  for (int i = 1; i <= num1; i++) {
    if(num1%i==0 && num2%i==0) {
      comun=i;
    }
  }
  print('El mínimo común divisor de los números es:' + '$comun');
}