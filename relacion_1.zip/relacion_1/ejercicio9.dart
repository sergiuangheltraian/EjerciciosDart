void main() {
  int numero;

  for (int i=1 ; i<10 ; i++) {
    print('Tabla del $i');
    for (int x=1 ; x<=10 ; x++) {
    numero=i*x;
    print('$numero');
    }
    print('\n');
  }
}