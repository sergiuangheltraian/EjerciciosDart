import 'dart:math';

void main() {
  var dado;
  int veces = 10,uno=0,dos=0,tres=0,cuatro=0,cinco=0,seis=0;
  for (int i = 1; i <= veces; i++) {
    dado = Random().nextInt(6) + 1;
    print('Dado lanzado: $dado');
    switch(dado) {
      case 1:
        uno++;
        break;
      case 2:
        dos++;
        break;
      case 3:
        tres++;
        break;
      case 4:
        cuatro++;
        break;
      case 5:
        cinco++;
        break;
      case 6:
        seis++;
        break;
    }
  }

  print('unos: $uno \ndos: $dos \ntres: $tres \ncuatro: $cuatro \ncinco: $cinco \nseis: $seis');
}