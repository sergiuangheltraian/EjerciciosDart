import 'dart:math';

void main() {
  var dado;
  dado = Random().nextInt(6) + 1;
  print('Dado lanzado: $dado');
}